package models;

/**
 * Created by Krystian on 2017-04-05.
 */
public class CSPVertexPair extends Tuple<Integer, Integer> {

    public CSPVertexPair(int firstColor, int secondColor) {
        super(firstColor, secondColor);
    }
}